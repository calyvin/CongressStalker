var express = require('express');
var app = express();
var fs = require('fs');
var ejs = require('ejs');
var bodyParser = require('body-parser');
var urlencodedBodyParser = bodyParser.urlencoded({extended: false});
var request = require('request');
var apikey = 'Cowto7nqKFyirfn3ml80rCQGM58eXx4NymaLPLro';

app.use(urlencodedBodyParser);
app.set('view_engine', 'ejs');

app.post('/legislators', function(req1, res1){
  var state=req1.body.state;
  var branch = req1.body.branch;
  console.log(branch);
  console.log(state);
  var options = {
	  url: "https://api.propublica.org/congress/v1/members/"+branch+"/"+state+"/current.json",
	  headers: {
	    "X-API-Key": apikey
	  }
	};// request options

  request(options, function(req2, res2, body){
      var propublica_data = JSON.parse(body);
      res1.render("legislators.ejs", {data: propublica_data.results});
  });//request for Probulica API query

});

app.get('/', function(req, res){
	var states_json = JSON.parse(fs.readFileSync("data/states.json"));
	res.render('index.ejs', {states: states_json.states});
});

app.listen(3000, function(){
	console.log('listening on port 3000!')
});